package com.yash.oops2;

public interface Shape {

	double area() ;
}
